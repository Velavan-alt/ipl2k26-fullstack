import { useState, useEffect, useCallback } from "react";
import Navbar from "@/components/Navbar";
import MatchCard from "@/components/MatchCard";
import BetSlip from "@/components/BetSlip";
import { FSMatch, FSBet, subscribeToMatches, getUserBets, placeBetFS, updateUserWallet, getAllUsers } from "@/services/firebaseService";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Wallet, History, TrendingUp, ArrowDownCircle, ArrowUpCircle, Send, User, Loader2 } from "lucide-react";
import { toast } from "sonner";

const TELEGRAM_URL = "https://t.me/cricbet007";

const UserPanel = () => {
  const { user } = useAuth();
  const [activeBet, setActiveBet]           = useState<{ match: FSMatch; selection: string } | null>(null);
  const [matches, setMatches]               = useState<FSMatch[]>([]);
  const [myBets, setMyBets]                 = useState<FSBet[]>([]);
  const [balance, setBalance]               = useState(0);
  const [loadingBet, setLoadingBet]         = useState(false);
  const [showTelegramModal, setShowTelegramModal] = useState<"deposit" | "withdraw" | null>(null);

  const email = user?.email || "";
  const displayName = user?.username ? `@${user.username}` : user?.name || "";

  // Real-time matches subscription
  useEffect(() => {
    const unsub = subscribeToMatches(setMatches);
    return unsub;
  }, []);

  // Load user bets + wallet balance
  const loadUserData = useCallback(async () => {
    if (!email) return;
    const [bets, allUsers] = await Promise.all([
      getUserBets(email),
      getAllUsers(),
    ]);
    setMyBets(bets);
    const me = allUsers.find((u) => u.email === email);
    if (me) setBalance(me.wallet);
  }, [email]);

  useEffect(() => { loadUserData(); }, [loadUserData]);

  const activeBetsCount = myBets.filter((b) => b.status === "pending").length;
  const totalWon = myBets.filter((b) => b.status === "won").reduce((s, b) => s + b.amount * b.odds, 0);

  const getOdds = (match: FSMatch, selection: string) => {
    if (selection.includes(match.team1)) return match.odds.team1Win;
    if (selection.includes(match.team2)) return match.odds.team2Win;
    return match.odds.draw;
  };

  const handlePlaceBet = async (amount: number) => {
    if (!activeBet || !user) return;
    if (amount > balance) { toast.error("Insufficient balance. Deposit via Telegram @cricbet007"); return; }

    setLoadingBet(true);
    try {
      const odds = getOdds(activeBet.match, activeBet.selection);
      // Deduct wallet first
      const allUsers = await getAllUsers();
      const me = allUsers.find((u) => u.email === email);
      if (!me?.id) { toast.error("User not found"); return; }
      await updateUserWallet(me.id, balance - amount);

      // Place bet
      await placeBetFS({
        userId: email,
        userName: user.name,
        matchId: activeBet.match.id!,
        matchTitle: `${activeBet.match.team1} vs ${activeBet.match.team2}`,
        selection: activeBet.selection,
        amount,
        odds,
        status: "pending",
      });

      toast.success(`Bet placed on ${activeBet.selection}!`);
      setActiveBet(null);
      await loadUserData();
    } catch (e) {
      toast.error("Failed to place bet. Try again.");
    } finally {
      setLoadingBet(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-8">

        {/* Wallet bar */}
        <div className="glass-card rounded-xl p-3 sm:p-4 mb-5 sm:mb-8">
          <div className="flex items-center justify-between gap-3 mb-3">
            <div className="flex items-center gap-2.5">
              <div className="gradient-gold rounded-full p-2 shrink-0"><User size={18} className="text-primary-foreground" /></div>
              <div>
                <p className="font-display font-bold text-foreground text-sm leading-tight">{displayName}</p>
                <p className="text-xs text-muted-foreground leading-tight">{user?.name}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Balance</p>
              <p className="font-display text-xl sm:text-2xl font-bold text-primary leading-tight">₹{balance.toLocaleString()}</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex gap-4 sm:gap-6">
              <div><p className="text-xs text-muted-foreground">Active Bets</p><p className="font-display font-bold text-foreground">{activeBetsCount}</p></div>
              <div><p className="text-xs text-muted-foreground">Total Won</p><p className="font-display font-bold text-success">₹{totalWon.toLocaleString()}</p></div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={() => setShowTelegramModal("deposit")}
                className="gradient-gold text-primary-foreground font-display font-bold tracking-wider text-xs gap-1 h-9 px-3 touch-manipulation">
                <ArrowDownCircle size={13} />DEPOSIT
              </Button>
              <Button size="sm" variant="outline" onClick={() => setShowTelegramModal("withdraw")}
                className="border-primary/40 text-primary hover:bg-primary/10 font-display font-bold tracking-wider text-xs gap-1 h-9 px-3 touch-manipulation">
                <ArrowUpCircle size={13} />WITHDRAW
              </Button>
            </div>
          </div>
        </div>

        {/* Telegram Modal */}
        {showTelegramModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4"
            onClick={() => setShowTelegramModal(null)}>
            <div className="glass-card rounded-t-2xl sm:rounded-2xl p-6 sm:p-8 w-full sm:max-w-sm border-primary/30 glow-gold text-center pb-8"
              onClick={(e) => e.stopPropagation()}>
              <div className="w-10 h-1 bg-border rounded-full mx-auto mb-5 sm:hidden" />
              <div className="gradient-gold rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                <Send size={26} className="text-primary-foreground" />
              </div>
              <h2 className="font-display text-lg font-bold text-gradient-gold tracking-wider mb-1">
                {showTelegramModal === "deposit" ? "DEPOSIT FUNDS" : "WITHDRAW FUNDS"}
              </h2>
              <p className="text-sm text-muted-foreground mb-5">
                {showTelegramModal === "deposit"
                  ? "Contact our Telegram support to add funds. Processed within minutes."
                  : "Contact our Telegram support to withdraw. Processed within 24 hours."}
              </p>
              <div className="bg-secondary border border-primary/20 rounded-lg px-4 py-3 mb-4 flex items-center justify-center gap-2">
                <Send size={15} className="text-primary" />
                <span className="font-display font-bold text-primary tracking-wider">@cricbet007</span>
              </div>
              <p className="text-xs text-muted-foreground mb-5">
                Mention your email <span className="text-primary font-semibold">{email}</span> and amount.
              </p>
              <div className="flex gap-2.5">
                <Button variant="outline" className="flex-1 h-11 border-border text-muted-foreground font-display text-xs touch-manipulation"
                  onClick={() => setShowTelegramModal(null)}>CANCEL</Button>
                <Button className="flex-1 h-11 gradient-gold text-primary-foreground font-display font-bold text-xs gap-1.5 touch-manipulation"
                  onClick={() => { window.open(TELEGRAM_URL, "_blank"); setShowTelegramModal(null); }}>
                  <Send size={13} />OPEN TELEGRAM
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Main grid */}
        <div className="grid lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          <div className="lg:col-span-2">
            <Tabs defaultValue="matches">
              <TabsList className="bg-secondary mb-4 sm:mb-6 w-full sm:w-auto">
                <TabsTrigger value="matches" className="flex-1 sm:flex-none font-display tracking-wider text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  <TrendingUp size={13} className="mr-1" />MATCHES
                </TabsTrigger>
                <TabsTrigger value="mybets" className="flex-1 sm:flex-none font-display tracking-wider text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  <History size={13} className="mr-1" />MY BETS
                </TabsTrigger>
              </TabsList>

              <TabsContent value="matches" className="space-y-3 sm:space-y-4">
                {matches.length === 0 ? (
                  <div className="glass-card rounded-lg p-8 text-center">
                    <Loader2 size={24} className="animate-spin text-primary mx-auto mb-2" />
                    <p className="text-muted-foreground font-display text-sm">Loading matches...</p>
                  </div>
                ) : (
                  matches.map((match) => (
                    <MatchCard key={match.id} match={match as any}
                      onBet={(m, s) => setActiveBet({ match: m as any, selection: s })}
                      onStatusChange={loadUserData} />
                  ))
                )}
              </TabsContent>

              <TabsContent value="mybets" className="space-y-3">
                {myBets.length === 0 ? (
                  <div className="glass-card rounded-lg p-8 text-center">
                    <p className="text-muted-foreground font-display">No bets placed yet. Pick a match!</p>
                  </div>
                ) : (
                  myBets.map((bet) => {
                    const betTeam = bet.selection.replace(" Win", "");
                    return (
                      <div key={bet.id} className="glass-card rounded-lg p-3 sm:p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <p className="font-display font-bold text-foreground text-sm truncate">{bet.matchTitle}</p>
                            <div className="inline-flex items-center gap-1.5 bg-primary/10 border border-primary/20 rounded-md px-2 py-0.5 mt-1.5">
                              <span className="text-xs text-muted-foreground">Bet on:</span>
                              <span className="font-display font-bold text-primary text-xs">{betTeam}</span>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">Odds: {bet.odds}x</p>
                          </div>
                          <div className="text-right shrink-0">
                            <p className="font-display font-bold text-primary">₹{bet.amount}</p>
                            <p className="text-xs text-muted-foreground">Win: ₹{(bet.amount * bet.odds).toFixed(0)}</p>
                            <Badge className={
                              bet.status === "won"  ? "bg-success/20 text-success border border-success/30 text-xs mt-1" :
                              bet.status === "lost" ? "bg-destructive/20 text-destructive border border-destructive/30 text-xs mt-1" :
                              "bg-warning/20 text-warning border border-warning/30 text-xs mt-1"
                            }>{bet.status.toUpperCase()}</Badge>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-3">
            {activeBet ? (
              <BetSlip
                matchTitle={`${activeBet.match.team1} vs ${activeBet.match.team2}`}
                selection={activeBet.selection}
                odds={getOdds(activeBet.match, activeBet.selection)}
                onClose={() => setActiveBet(null)}
                onPlaceBet={handlePlaceBet}
                balance={balance}
                loading={loadingBet}
              />
            ) : (
              <div className="glass-card rounded-lg p-6 text-center">
                <TrendingUp size={36} className="text-muted-foreground mx-auto mb-3" />
                <p className="font-display text-sm text-muted-foreground tracking-wider">SELECT ODDS TO PLACE A BET</p>
              </div>
            )}
            <div className="glass-card rounded-lg p-4 border-primary/20">
              <p className="font-display text-xs text-muted-foreground tracking-wider mb-3">NEED HELP?</p>
              <button onClick={() => window.open(TELEGRAM_URL, "_blank")}
                className="w-full flex items-center gap-3 bg-secondary hover:bg-secondary/70 border border-border hover:border-primary/40 rounded-lg px-3 py-2.5 transition-all touch-manipulation">
                <div className="gradient-gold rounded-full p-1.5 shrink-0"><Send size={13} className="text-primary-foreground" /></div>
                <div className="text-left">
                  <p className="font-display text-xs font-bold text-primary tracking-wider">@cricbet007</p>
                  <p className="text-xs text-muted-foreground">Deposit · Withdraw · Support</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserPanel;
