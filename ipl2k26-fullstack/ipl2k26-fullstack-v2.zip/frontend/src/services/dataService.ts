import { Match, Bet } from "@/data/mockData";

// ⚠️  These MUST match STORAGE_KEYS in AuthContext.tsx exactly
const MATCHES_KEY = "ipl2k26_matches";
const BETS_KEY    = "ipl2k26_bets";
const WALLETS_KEY = "ipl2k26_wallets";
const USERS_KEY   = "ipl2k26_users";

// Default seed matches
const defaultMatches: Match[] = [
  {
    id: "1", team1: "Mumbai Indians", team2: "Chennai Super Kings",
    team1Score: "187/4", team2Score: "142/3",
    status: "live", overs: "15.2", venue: "Wankhede Stadium, Mumbai",
    date: "2026-03-20", startTime: "20:00",
    odds: { team1Win: 1.75, team2Win: 2.10, draw: 14.0 },
  },
  {
    id: "2", team1: "Royal Challengers Bengaluru", team2: "Kolkata Knight Riders",
    team1Score: "201/5", team2Score: "-",
    status: "live", overs: "20.0", venue: "M. Chinnaswamy Stadium, Bengaluru",
    date: "2026-03-20", startTime: "16:00",
    odds: { team1Win: 1.90, team2Win: 1.95, draw: 15.0 },
  },
  {
    id: "3", team1: "Rajasthan Royals", team2: "Delhi Capitals",
    team1Score: "-", team2Score: "-",
    status: "upcoming", overs: "-", venue: "Sawai Mansingh Stadium, Jaipur",
    date: "2026-03-21", startTime: "20:00",
    odds: { team1Win: 2.00, team2Win: 1.85, draw: 13.0 },
  },
  {
    id: "4", team1: "Punjab Kings", team2: "Gujarat Titans",
    team1Score: "-", team2Score: "-",
    status: "upcoming", overs: "-", venue: "PCA Stadium, Mohali",
    date: "2026-03-22", startTime: "20:00",
    odds: { team1Win: 2.15, team2Win: 1.70, draw: 13.5 },
  },
];

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch { return fallback; }
}

function write<T>(key: string, data: T) {
  localStorage.setItem(key, JSON.stringify(data));
}

// MATCHES
export const getMatches = (): Match[] => read(MATCHES_KEY, defaultMatches);

// ── Auto-live helpers ─────────────────────────────────────────────────────────

/**
 * Returns the JS Date for when a match should go live.
 * Combines match.date ("YYYY-MM-DD") + match.startTime ("HH:MM").
 */
export const getMatchStartDateTime = (match: Match): Date => {
  return new Date(`${match.date}T${match.startTime}:00`);
};

/**
 * Returns seconds remaining until a match starts.
 * Negative means the start time has already passed.
 */
export const secondsUntilStart = (match: Match): number => {
  return Math.floor((getMatchStartDateTime(match).getTime() - Date.now()) / 1000);
};

/**
 * Scans all upcoming matches and flips any whose startTime has passed to "live".
 * Call this on an interval (see startAutoLiveScheduler).
 * Returns the number of matches transitioned.
 */
export const autoTransitionMatches = (): number => {
  const matches = getMatches();
  let changed = 0;
  const updated = matches.map((m) => {
    if (m.status === "upcoming" && secondsUntilStart(m) <= 0) {
      changed++;
      return { ...m, status: "live" as const };
    }
    return m;
  });
  if (changed > 0) write(MATCHES_KEY, updated);
  return changed;
};

/**
 * Admin: manually set a single match live immediately.
 */
export const goLiveNow = (id: string): void => {
  const matches = getMatches().map((m) =>
    m.id === id ? { ...m, status: "live" as const } : m
  );
  write(MATCHES_KEY, matches);
};

/**
 * Admin: update a match's date/startTime (reschedule).
 */
export const rescheduleMatch = (id: string, date: string, startTime: string): void => {
  const matches = getMatches().map((m) =>
    m.id === id ? { ...m, date, startTime, status: "upcoming" as const } : m
  );
  write(MATCHES_KEY, matches);
};

/**
 * Starts a background interval that checks for matches to go live every 30 seconds.
 * Returns a cleanup function — call it on component unmount.
 */
export const startAutoLiveScheduler = (onTransition?: (count: number) => void): (() => void) => {
  // Run once immediately
  const count = autoTransitionMatches();
  if (count > 0) onTransition?.(count);

  const id = window.setInterval(() => {
    const n = autoTransitionMatches();
    if (n > 0) onTransition?.(n);
  }, 30_000); // every 30 seconds

  return () => window.clearInterval(id);
};

export const addMatch = (match: Omit<Match, "id">): Match => {
  const matches = getMatches();
  const newMatch: Match = { ...match, id: Date.now().toString() };
  matches.push(newMatch);
  write(MATCHES_KEY, matches);
  return newMatch;
};

export const deleteMatch = (id: string) => {
  const matches = getMatches().filter((m) => m.id !== id);
  write(MATCHES_KEY, matches);
};

// BETS
export const getBets = (): Bet[] => read(BETS_KEY, []);

export const placeBet = (bet: Omit<Bet, "id" | "placedAt">): Bet => {
  const bets = getBets();
  const newBet: Bet = {
    ...bet,
    id: Date.now().toString(),
    placedAt: new Date().toLocaleString(),
  };
  bets.push(newBet);
  write(BETS_KEY, bets);
  // Deduct from wallet
  const wallet = getWallet(bet.userId);
  setWallet(bet.userId, wallet - bet.amount);
  return newBet;
};

export const getUserBets = (userId: string): Bet[] =>
  getBets().filter((b) => b.userId === userId);


// ── Result declaration ────────────────────────────────────────────────────────

/**
 * Declare the winner of a match and settle all pending bets.
 * Winners get credited: stake × odds_at_bet
 * Losers: stake already deducted — no change needed
 */
export const declareResult = (
  matchId: string,
  winner: "team1" | "team2" | "draw"
): { won: number; lost: number; totalPayout: number } => {
  // 1. Mark match as completed with winner
  const matches = getMatches().map((m) =>
    m.id === matchId
      ? { ...m, status: "completed" as const, winner }
      : m
  );
  write(MATCHES_KEY, matches);

  // 2. Settle all pending bets for this match
  const match = matches.find((m) => m.id === matchId);
  if (!match) return { won: 0, lost: 0, totalPayout: 0 };

  const winningSelection =
    winner === "team1" ? `${match.team1} Win` :
    winner === "team2" ? `${match.team2} Win` :
    "Draw";

  const allBets  = getBets();
  let won = 0, lost = 0, totalPayout = 0;

  const updatedBets = allBets.map((bet) => {
    if (bet.matchId !== matchId || bet.status !== "pending") return bet;

    const userWon = bet.selection === winningSelection;
    if (userWon) {
      // Credit winnings to wallet
      const payout = parseFloat((bet.amount * bet.odds).toFixed(2));
      addMoney(bet.userId, payout);
      won++;
      totalPayout += payout;
      return { ...bet, status: "won" as const };
    } else {
      lost++;
      return { ...bet, status: "lost" as const };
    }
  });

  write(BETS_KEY, updatedBets);
  return { won, lost, totalPayout };
};

// WALLETS
export const getWallet = (userEmail: string): number => {
  const wallets: Record<string, number> = read(WALLETS_KEY, {});
  return wallets[userEmail] ?? 0;
};

export const setWallet = (userEmail: string, amount: number) => {
  const wallets: Record<string, number> = read(WALLETS_KEY, {});
  wallets[userEmail] = amount;
  write(WALLETS_KEY, wallets);
};

export const addMoney = (userEmail: string, amount: number): number => {
  const current = getWallet(userEmail);
  const newBalance = current + amount;
  setWallet(userEmail, newBalance);
  return newBalance;
};

// USERS (registered users list)
export interface RegisteredUser {
  name: string;
  username: string;
  email: string;
  password: string;
}

export const getRegisteredUsers = (): RegisteredUser[] => read(USERS_KEY, []);
