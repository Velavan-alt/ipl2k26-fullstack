import { useState, useEffect } from "react";
import { Clock, Zap } from "lucide-react";
import { Match } from "@/data/mockData";
import { secondsUntilStart } from "@/services/dataService";

interface MatchCountdownProps {
  match: Match;
  onExpired?: () => void; // called when countdown hits zero
}

function formatCountdown(seconds: number): string {
  if (seconds <= 0) return "Starting now...";
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;

  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  return `${m}m ${s}s`;
}

const MatchCountdown = ({ match, onExpired }: MatchCountdownProps) => {
  const [secs, setSecs] = useState(() => secondsUntilStart(match));

  useEffect(() => {
    if (match.status !== "upcoming") return;

    const id = setInterval(() => {
      const remaining = secondsUntilStart(match);
      setSecs(remaining);
      if (remaining <= 0) {
        clearInterval(id);
        onExpired?.();
      }
    }, 1000);

    return () => clearInterval(id);
  }, [match, onExpired]);

  if (match.status !== "upcoming") return null;

  const isImminent = secs <= 300 && secs > 0; // under 5 minutes

  return (
    <span
      className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-mono font-semibold ${
        isImminent
          ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 animate-pulse"
          : "bg-primary/10 text-primary border border-primary/20"
      }`}
    >
      {isImminent ? <Zap size={11} /> : <Clock size={11} />}
      {secs <= 0 ? "Going live…" : formatCountdown(secs)}
    </span>
  );
};

export default MatchCountdown;
